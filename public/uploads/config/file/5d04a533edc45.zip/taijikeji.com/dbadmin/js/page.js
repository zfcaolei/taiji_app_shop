var page = 1;




function pages() {

    var pagelist = ' <li><a onclick="pre()">上一页</a></li>'
    pagelist += '  <li><a onclick="datalook(1)" id="1">首页</a></li>'
    if (page < 5) {


        pagelist += '  <li id="1"><a onclick="datalook(1)">1</a></li>'
        pagelist += '   <li id="2"><a onclick="datalook(2)">2</a></li>'
        pagelist += '  <li id="3"><a onclick="datalook(3)">3</a></li>'
        pagelist += ' <li id="4"><a onclick="datalook(4)">4</a></li>'
        pagelist += ' <li ><a onclick="javascript:void(0)">.....</a></li>'
        pagelist += '  <li id="18"><a onclick="datalook(18)">18</a></li>'
        pagelist += '   <li id="19"><a onclick="datalook(19)">19</a></li>'
        pagelist += '  <li id="20"><a onclick="datalook(20)">20</a></li>'


    } else if (page > 15) {
        pagelist += '  <li id="13"><a onclick="datalook(13)">13</a></li>'
        pagelist += '   <li id="14"><a onclick="datalook(14)">14</a></li>'
        pagelist += '  <li id="15"><a onclick="datalook(15)">15</a></li>'
        pagelist += ' <li id="16"><a onclick="datalook(16)">16</a></li>'
        pagelist += ' <li id="17"><a onclick="datalook(17)">17</a></li>'
        pagelist += '  <li id="18"><a onclick="datalook(18)">18</a></li>'
        pagelist += '   <li id="19"><a onclick="datalook(19)">19</a></li>'
        pagelist += '  <li id="20"><a onclick="datalook(20)">20</a></li>'
    } else {


        for (let i = page - 3; i <= page; i++) {
            pagelist += '  <li id=' + i + '><a onclick="datalook(' + i + ')">' + i + '</a></li>'

        }
        pagelist += ' <li ><a onclick="javascript:void(0)">.....</a></li>'
        pagelist += '  <li id="18"><a  onclick="datalook(18)">18</a></li>'
        pagelist += '   <li id="19"><a onclick="datalook(19)">19</a></li>'
        pagelist += '  <li id="20"><a onclick="datalook(20)">20</a></li>'
    }


    pagelist += '<li><a onclick="next()">下一页</a></li>'
    $('.page_list').html(pagelist)

    atc()
        /* Render the template with the movies data and insert
           the rendered HTML under the "movieList" element */


}
// pages();


function datalook(x) {

    page = x;
    pages()
    log()
    atc()
	keyword()
        // $('.page_list').find('li').parents().siblings().children().removeClass('cur')
        // $('.page_list').find('a').eq(x).addClass('cur').parents().siblings().children().removeClass('cur');
}

function atc() {
    $('.page_list').find('li').each(function() {
        $(this).removeClass('cur')
        if ($(this).attr('id') == page) {
            $(this).addClass('cur')
        }
    })
}

function pre() {
    if (page == 1) {

        alert('当前是第一页')

    } else {
        page = page - 1;
        datalook(page)
    }

}

function next() {
    if (page == 20) {

        alert('当前是最后一页')

    } else {
        page = page + 1;
        datalook(page)
    }

}
// var movies = JSON.parse(res)
// var markup = "<tr class='odd'><td><input name='' type='checkbox' value=''> </td><td>${id}</td><td>${keyword}</td><td style='width:300px'>${ addtime}</td><td><a href='####' style='color:red'>删除</a></td></tr>";

// /* Compile the markup as a named template */
// $.template("movieTemplate", markup);

// /* Render the template with the movies data and insert
//    the rendered HTML under the "movieList" element */
// $.tmpl("movieTemplate", movies)
//     .appendTo("#movieList tbody");

function keyword() {
	
    $.ajax({
        type: "get",
        async: false,
        url: "http://zg4db.com/tp/index.php/home/keyword/index",
        data: {
            p: page
        },
        // jsonp: "callbackparam", //传递给请求处理程序或页面的，用以获得jsonp回调函数名的参数名(默认为:callback
        success: function(json) {
            // var json = eval('{' + json + '}');
            // console.log(page, json)
            $('#movieList tbody').empty();
            json.forEach(function(v, b) {

                markup = "<tr class='odd'><td><input name='' type='checkbox' value=''> </td><td>${id}</td><td>${keyword}</td><td style='width:300px'>${ addtime}</td><td><a href='####' style='color:red'>删除</a></td></tr>";

                /* Compile the markup as a named template */
                $.template("movieTemplate", markup);

                /* Render the template with the movies data and insert
                   the rendered HTML under the "movieList" element */
                $.tmpl("movieTemplate", v)
                    .appendTo("#movieList tbody");
            });

        },
        error: function() {
            alert('fail');
        }
    });

}

function log() {
    $.ajax({
        type: "get",
        async: false,
        url: "http://zg4db.com/tp/index.php/home/log/index",
        data: {
            p: page
        },
        // jsonp: "callbackparam", //传递给请求处理程序或页面的，用以获得jsonp回调函数名的参数名(默认为:callback
        success: function(json) {
            // var json = eval('{' + json + '}');
            // console.log(page, json)
            $('#movieList1 tbody').empty();
            json.forEach(function(v, b) {

                markup = "<tr class='odd'><td><input name='' type='checkbox' value=''> </td><td>${id}</td><td>${createtime}</td><td>${username}</td><td>${ip}</td><td>${title}</td><td>${url}</td></tr>";

                /* Compile the markup as a named template */
                $.template("movieTemplate", markup);

                /* Render the template with the movies data and insert
                   the rendered HTML under the "movieList" element */
                $.tmpl("movieTemplate", v)
                    .appendTo("#movieList1 tbody");
            });

        },
        error: function() {
            alert('fail');
        }
    });

}